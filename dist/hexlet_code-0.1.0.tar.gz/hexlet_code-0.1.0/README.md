### Hexlet tests and linter status:
[![Actions Status](https://github.com/pashkovsky-k/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/pashkovsky-k/python-project-49/actions)
# Brain Games (Python)
## Brain-even
Successful completion:
[![asciicast](https://asciinema.org/a/FafHqb88F0TlIrUCFv5Y894wC.svg)](https://asciinema.org/a/FafHqb88F0TlIrUCFv5Y894wC)
Losing:
[![asciicast](https://asciinema.org/a/gTy8PG8BXxxTt17h9Oc6uLdRq.svg)](https://asciinema.org/a/gTy8PG8BXxxTt17h9Oc6uLdRq)
## Brain-calc
Successful completion:
[![asciicast](https://asciinema.org/a/OWBE3S5Kjdch87Z7WPFE2pqsC.svg)](https://asciinema.org/a/OWBE3S5Kjdch87Z7WPFE2pqsC)
Losing:
[![asciicast](https://asciinema.org/a/8F2tqp4hzlacUA8HdeNfReQiR.svg)](https://asciinema.org/a/8F2tqp4hzlacUA8HdeNfReQiR)
## Brain-gcd
Successful completion:
[![asciicast](https://asciinema.org/a/qT0GgJzDCYtALnWCXJVbZpiu5.svg)](https://asciinema.org/a/qT0GgJzDCYtALnWCXJVbZpiu5)
Losing:
[![asciicast](https://asciinema.org/a/XMSwRrewWM7k3MWGlhVb3NeyR.svg)](https://asciinema.org/a/XMSwRrewWM7k3MWGlhVb3NeyR)